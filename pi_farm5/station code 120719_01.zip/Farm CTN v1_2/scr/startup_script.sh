#!/bin/bash
echo "Farm Box Boot-up"
cd /home/multiply/memo
python -m SimpleHTTPServer &